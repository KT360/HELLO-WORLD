﻿
using UnityEngine;

public class SRIPT : MonoBehaviour {

	public Rigidbody rb;
	public float CatapultForce = 400f;


	void FixedUpdate () 
	{


		if (Input.GetKey("w")) 
		{
			rb.AddForce (0, CatapultForce, 0);


		}



	}
}
